//: A Cocoa based Playground to present user interface

import AppKit
import PlaygroundSupport

let nibFile = NSNib.Name("MyView")
var topLevelObjects : NSArray?

Bundle.main.loadNibNamed(nibFile, owner:nil, topLevelObjects: &topLevelObjects)
let views = (topLevelObjects as! Array<Any>).filter { $0 is NSView }

// Present the view in Playground
PlaygroundPage.current.liveView = views[0] as! NSView

/*: quand il y aura 3 perso par équipe
 var perso1_1 = Personnage(name:"Dadou", team: "team1")
 var perso1_2 = Personnage(name:"Abc", team: "team1")
 var perso1_3 = Personnage(name:"Defgh", team: "team1")
 
 var perso2_1 = Personnage(name:"Ijk", team: "team2")
 var perso2_2 = Personnage(name:"Lmn", team: "team2")
 var perso2_3 = Personnage(name:"Opq", team: "team2")
 */

class Personnage {
    var name : String
    var team : String
    var life = 100
    var weapon = 25
    
    init(name: String, team: String) {
        self.name = name
        self.team = team
    }
}


class Player {
    var perso : String
    var isInLife : Bool
    var roundNb : Int
    
    init(perso: String, isInLife: Bool, roundNb: Int) {
        self.perso = perso
        self.isInLife = true
        self.roundNb = 0
    }
}








var perso1 = Personnage(name:"Dadou", team: "team1")
var perso2 = Personnage(name:"Ijk", team: "team2")


//: perso1_1 attaque perso2_1

func round () {
    var roundNb = 0
    while perso2.life > 0 {
        //: si numéro du tour est impair alors joueur 1 attaque
        if roundNb % 2 > 0 {
            perso2.life -= perso1.weapon
            roundNb += 1
            print("Round \(roundNb) Dadou attaque")
            print("Il reste \(perso2.life) points de vie à Ijk")
            print("fin du round\(roundNb) !")
        }
            //: sinon c'est que le numéro du tour est pair alors joueur 2 attaque
        else {
        perso1.life -= perso2.weapon
        roundNb += 1
        print("Round \(roundNb) IJK attaque")
        print("Il reste \(perso1.life) points de vie à Dadou")
        print("fin du round\(roundNb) !")
        }
        
    }
}

/*:
 initialisation du jeu:
 ---- on oublie si nbTour <1 alors joueur 1 joue
 if roundNb < 1 {
    attack() -----
 */
 
 /*:
 puis faire un boucle while tant qu'il y a une équipe en vie
 while player1.isInLife == true || player2.isInLife == true
 faire un modulo pour le compte tour :
 si nbTour impair alors joueur  joue
 si nbTour pair alors joueur 2 joue
 
 */

round ()
