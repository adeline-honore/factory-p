//: A Cocoa based Playground to present user interface

import AppKit
import PlaygroundSupport

let nibFile = NSNib.Name("MyView")
var topLevelObjects : NSArray?

Bundle.main.loadNibNamed(nibFile, owner:nil, topLevelObjects: &topLevelObjects)
let views = (topLevelObjects as! Array<Any>).filter { $0 is NSView }

// Present the view in Playground
PlaygroundPage.current.liveView = views[0] as! NSView

//: Diagramme de classes
class Personnage {
    var name : String
    var team : String
    var life = 100
    var weapon = 25
}

class Player {
    var perso1 : String
    var perso2 : String
    var perso3 : String
    var isInLife : Bool
    var roundNb : Int
}

class Round {
    var whoPlay : String
    
    func victoire () {}
}

class Action {
    func attack () {}
    
    func care() {}
}
    

//: Les différentes fonctions

victoire () {
    var message = "La partie est terminée. Le joueur " + joueurGagnant + "a gagné avec " + points + " points"
    print(message)
}

func choosePerso () {
    //: boucle while pour enregistrer 3 perso dans chaque équipe
    while ..<6 {
        print("Joueur 1. Ecris le prénom de ton deuxième personnage")
    }
}







/*:
 # Place au jeu
 */

print("Bonjour et bienvenue dans ce nouveau jeu de combat !")
print("Vous allez choisir les noms de vos trois personnages. Attention, les noms doivent tous être différents")

/*:
 ## Initialisation du jeu
 */
    var persoArray : String = []
choosePerso ()
    
print("Joueur 1. Ecris le prénom de ton premier personnage")
var perso1in1 = Personnage()
perso1in1.name = ""
    if perso1in1
print("Joueur 1. Ecris le prénom de ton deuxième personnage")
print("Joueur 1. Ecris le prénom de ton dernier personnage")

print("Joueur 2, c'est à ton tour")
print("Joueur 2. Ecris le prénom de ton premier personnage")
print("Joueur 2. Ecris le prénom de ton deuxième personnage")
print("Joueur 2. Ecris le prénom de ton dernier personnage")

/*:
 ## Combat au tour à tour
 Ici les tours sont répéts x fois jusqu'à la mort de tous les joueurs d'une équipe
 */

/*
 */
if player1.isInLife = True && player2.isInLife = True {
    // alors début du jeu

    if turnNumber < 1 {
        
    } else {
        if team1NbT < team2NbT {
            alors joueur 1 joue
            team1Nbt +=1
        }
        if team1NbT > team2NbT {
            alors joueur 2 joue
            team2Nbt +=1
        }
        
    }
} else {
    victoire ()
}
